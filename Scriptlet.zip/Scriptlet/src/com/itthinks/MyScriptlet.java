/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.itthinks;

import java.io.IOException;
import net.sf.jasperreports.engine.JRDefaultScriptlet;
import net.sf.jasperreports.engine.JRScriptletException;

/**
 *
 * @author viii
 */
public class MyScriptlet extends JRDefaultScriptlet {
 long pageInitTime = 0;
 private String[] dPath= new String[1];
 
 @Override
 public void beforePageInit() throws JRScriptletException {
 
 pageInitTime = new java.util.Date().getTime();
getJarName();
 }
 /**
 * @return the time past from the last page init
 */
 public Long getLastPageTime() {
 long now = new java.util.Date().getTime();
 return now - pageInitTime;
 }
 public  String getJarName() {
        String lk = new java.io.File(MyScriptlet.class.getProtectionDomain().getCodeSource().getLocation().getPath()).getPath();
        
        
        return lk;

    }
 public  String getpath1() {
      dPath = getJarName().split("dist");
      return dPath[0];
  }
 public  String getpath2() {
      dPath = getJarName().split("dist");
      return dPath[1];
  }
 public static void main(String[] args) throws IOException, JRScriptletException {
     
        System.out.println(new MyScriptlet().getpath1());
        System.out.println(new MyScriptlet().getpath2());
        System.out.println(new MyScriptlet().getJarName());
     }
}
